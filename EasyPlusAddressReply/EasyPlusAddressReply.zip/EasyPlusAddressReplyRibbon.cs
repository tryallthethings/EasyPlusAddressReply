using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Office = Microsoft.Office.Core;

namespace EasyPlusAddressReply
{
    [ComVisible(true)]
    public sealed class EasyPlusAddressReplyRibbon : Office.IRibbonExtensibility
    {
        private static Office.IRibbonUI _ribbonUi;

        public string GetCustomUI(string ribbonID)
        {
            try { Localization.ApplyOfficeUiCulture(Globals.ThisAddIn.Application); } catch { }

            if (!string.Equals(ribbonID, "Microsoft.Outlook.Explorer", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(ribbonID, "Microsoft.Outlook.Mail.Read", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            return @"<?xml version='1.0' encoding='UTF-8'?>
<customUI xmlns='http://schemas.microsoft.com/office/2009/07/customui' onLoad='OnLoad'>
  <ribbon>
    <tabs>
      <tab id='EparTab'
           insertAfterMso='TabAddIns'
           getLabel='GetLabel'>
        <group id='EparStatusGroup' getLabel='GetLabel'>
          <toggleButton id='EparEnabled'
                        size='large'
                        getLabel='GetLabel'
                        getImage='GetSwitchImage'
                        getPressed='GetPressed'
                        getScreentip='GetScreenTip'
                        onAction='OnToggleEnabled'/>
        </group>
        <group id='EparConfigurationGroup' getLabel='GetLabel'>
          <button id='EparSettings'
                  size='large'
                  imageMso='AdvancedFileProperties'
                  getLabel='GetLabel'
                  getScreentip='GetScreenTip'
                  onAction='OnSettings'/>
        </group>
        <group id='EparToolsGroup' getLabel='GetLabel'>
          <button id='EparDiagnose'
                  size='large'
                  imageMso='MessageHeaderToggle'
                  getLabel='GetLabel'
                  getScreentip='GetScreenTip'
                  onAction='OnDiagnose'/>
        </group>
      </tab>
    </tabs>
  </ribbon>
</customUI>";
        }

        public void OnLoad(Office.IRibbonUI ribbonUi)
        {
            _ribbonUi = ribbonUi;
        }

        public string GetLabel(Office.IRibbonControl control)
        {
            switch (control?.Id)
            {
                case "EparTab": return Strings.Get("AppName");
                case "EparStatusGroup": return Strings.Get("RibbonStatusGroup");
                case "EparConfigurationGroup": return Strings.Get("RibbonConfigurationGroup");
                case "EparToolsGroup": return Strings.Get("RibbonToolsGroup");
                case "EparEnabled":
                    return GetEnabledState()
                        ? Strings.Get("RibbonEnabledOn")
                        : Strings.Get("RibbonEnabledOff");
                case "EparSettings": return Strings.Get("RibbonSettings");
                case "EparDiagnose": return Strings.Get("RibbonDiagnose");
                default: return Strings.Get("AppName");
            }
        }

        public string GetScreenTip(Office.IRibbonControl control)
        {
            switch (control?.Id)
            {
                case "EparEnabled": return Strings.Get("RibbonEnabledTip");
                case "EparSettings": return Strings.Get("RibbonSettingsTip");
                case "EparDiagnose": return Strings.Get("RibbonDiagnoseTip");
                default: return Strings.Get("AppName");
            }
        }

        public bool GetPressed(Office.IRibbonControl control)
        {
            return GetEnabledState();
        }

        public object GetSwitchImage(Office.IRibbonControl control)
        {
            return RibbonSwitchImages.Get(GetEnabledState());
        }

        public void OnToggleEnabled(Office.IRibbonControl control, bool pressed)
        {
            Globals.ThisAddIn.Service?.SetEnabled(pressed);
        }

        public void OnSettings(Office.IRibbonControl control)
        {
            Globals.ThisAddIn.Service?.ShowSettings();
        }

        public void OnDiagnose(Office.IRibbonControl control)
        {
            Globals.ThisAddIn.Service?.DiagnoseSelectedMessage();
        }

        internal static void ReleaseRibbon()
        {
            _ribbonUi = null;
            RibbonSwitchImages.Dispose();
        }

        internal static void InvalidateState()
        {
            try { _ribbonUi?.InvalidateControl("EparEnabled"); }
            catch { }
        }

        private static bool GetEnabledState()
        {
            return Globals.ThisAddIn.Service?.Settings.Enabled ?? true;
        }

        /// <summary>
        /// RibbonX does not provide a native switch control. A toggleButton is the native
        /// stateful control, so we render a compact switch glyph and let Outlook retain its
        /// normal pressed/unpressed accessibility and keyboard behavior.
        /// </summary>
        private static class RibbonSwitchImages
        {
            private static Bitmap _onBitmap;
            private static Bitmap _offBitmap;
            private static stdole.IPictureDisp _onPicture;
            private static stdole.IPictureDisp _offPicture;

            internal static object Get(bool enabled)
            {
                if (enabled)
                {
                    if (_onPicture == null)
                    {
                        _onBitmap = CreateSwitchBitmap(true);
                        _onPicture = PictureDispConverter.ToPictureDisp(_onBitmap);
                    }

                    return _onPicture;
                }

                if (_offPicture == null)
                {
                    _offBitmap = CreateSwitchBitmap(false);
                    _offPicture = PictureDispConverter.ToPictureDisp(_offBitmap);
                }

                return _offPicture;
            }

            internal static void Dispose()
            {
                ReleasePicture(ref _onPicture);
                ReleasePicture(ref _offPicture);

                _onBitmap?.Dispose();
                _offBitmap?.Dispose();
                _onBitmap = null;
                _offBitmap = null;
            }

            private static Bitmap CreateSwitchBitmap(bool enabled)
            {
                var bitmap = new Bitmap(32, 32, PixelFormat.Format32bppPArgb);

                using (var graphics = Graphics.FromImage(bitmap))
                {
                    graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    graphics.Clear(Color.Transparent);

                    var trackRect = new RectangleF(2f, 9f, 28f, 14f);
                    using (var track = RoundedRectangle(trackRect, 7f))
                    using (var trackBrush = new SolidBrush(enabled
                        ? Color.FromArgb(15, 108, 189)
                        : Color.FromArgb(117, 117, 117)))
                    {
                        graphics.FillPath(trackBrush, track);
                    }

                    float thumbX = enabled ? 18f : 4f;
                    using (var shadowBrush = new SolidBrush(Color.FromArgb(45, 0, 0, 0)))
                    using (var thumbBrush = new SolidBrush(Color.White))
                    {
                        graphics.FillEllipse(shadowBrush, thumbX, 11.5f, 10.5f, 10.5f);
                        graphics.FillEllipse(thumbBrush, thumbX, 11f, 10f, 10f);
                    }
                }

                return bitmap;
            }

            private static GraphicsPath RoundedRectangle(RectangleF rectangle, float radius)
            {
                float diameter = radius * 2f;
                var path = new GraphicsPath();

                path.AddArc(rectangle.Left, rectangle.Top, diameter, diameter, 180, 90);
                path.AddArc(rectangle.Right - diameter, rectangle.Top, diameter, diameter, 270, 90);
                path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
                path.AddArc(rectangle.Left, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
                path.CloseFigure();

                return path;
            }

            private static void ReleasePicture(ref stdole.IPictureDisp picture)
            {
                if (picture == null)
                    return;

                try
                {
                    if (Marshal.IsComObject(picture))
                        Marshal.FinalReleaseComObject(picture);
                }
                catch { }
                finally
                {
                    picture = null;
                }
            }

            private sealed class PictureDispConverter : AxHost
            {
                private PictureDispConverter() : base(string.Empty) { }

                internal static stdole.IPictureDisp ToPictureDisp(Image image)
                {
                    return (stdole.IPictureDisp)GetIPictureDispFromPicture(image);
                }
            }
        }
    }
}
