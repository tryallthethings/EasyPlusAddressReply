using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyPlusAddressReply
{
    internal sealed class OptionsForm : Form
    {
        private readonly CheckBox _enabled = new CheckBox();
        private readonly TextBox _bases = new TextBox();
        private readonly CheckBox _headerFallback = new CheckBox();
        private readonly TextBox _headers = new TextBox();
        private readonly CheckBox _warnAmbiguous = new CheckBox();
        private readonly CheckBox _reapply = new CheckBox();

        public EasyPlusAddressReplySettings Result { get; private set; }

        public OptionsForm(EasyPlusAddressReplySettings current)
        {
            Text = "Reply Alias settings";
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ClientSize = new Size(620, 500);
            Font = SystemFonts.MessageBoxFont;

            int x = 18, y = 18, w = 580;

            _enabled.SetBounds(x, y, w, 24);
            _enabled.Text = "Enable automatic From selection on Reply and Reply All";
            Controls.Add(_enabled);
            y += 40;

            var baseLabel = new Label
            {
                Text = "Base email addresses (one per line)",
                AutoSize = true
            };
            baseLabel.Location = new Point(x, y);
            Controls.Add(baseLabel);
            y += 24;

            _bases.SetBounds(x, y, w, 90);
            _bases.Multiline = true;
            _bases.ScrollBars = ScrollBars.Vertical;
            Controls.Add(_bases);
            y += 96;

            var baseHint = new Label
            {
                Text = "Leave blank to use the SMTP address of each Outlook account automatically.\r\n" +
                       "Example: name@domain.com matches name+anything@domain.com.",
                AutoSize = true
            };
            baseHint.Location = new Point(x, y);
            Controls.Add(baseHint);
            y += 48;

            _headerFallback.SetBounds(x, y, w, 24);
            _headerFallback.Text = "Use raw message headers when Outlook's recipient list has no unique match";
            Controls.Add(_headerFallback);
            y += 32;

            var headerLabel = new Label { Text = "Headers to inspect", AutoSize = true };
            headerLabel.Location = new Point(x, y);
            Controls.Add(headerLabel);
            y += 22;

            _headers.SetBounds(x, y, w, 24);
            Controls.Add(_headers);
            y += 38;

            _warnAmbiguous.SetBounds(x, y, w, 24);
            _warnAmbiguous.Text = "Warn instead of guessing when multiple matching aliases are found";
            Controls.Add(_warnAmbiguous);
            y += 30;

            _reapply.SetBounds(x, y, w, 42);
            _reapply.Text = "Reapply and verify the selected alias when Send is clicked\r\n" +
                            "(safer, but will override a manual From change made after Reply)";
            Controls.Add(_reapply);
            y += 54;

            var ok = new Button { Text = "OK", DialogResult = DialogResult.OK };
            ok.SetBounds(438, 450, 78, 30);
            ok.Click += (_, __) => SaveResult();
            Controls.Add(ok);

            var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel };
            cancel.SetBounds(524, 450, 78, 30);
            Controls.Add(cancel);

            AcceptButton = ok;
            CancelButton = cancel;

            _enabled.Checked = current.Enabled;
            _bases.Text = current.BaseAddresses ?? "";
            _headerFallback.Checked = current.UseHeaderFallback;
            _headers.Text = current.HeaderNames ?? "";
            _warnAmbiguous.Checked = current.WarnOnAmbiguousMatch;
            _reapply.Checked = current.ReapplyOnSend;
        }

        private void SaveResult()
        {
            Result = new EasyPlusAddressReplySettings
            {
                Enabled = _enabled.Checked,
                BaseAddresses = _bases.Text,
                UseHeaderFallback = _headerFallback.Checked,
                HeaderNames = _headers.Text,
                WarnOnAmbiguousMatch = _warnAmbiguous.Checked,
                ReapplyOnSend = _reapply.Checked
            };
        }
    }
}
