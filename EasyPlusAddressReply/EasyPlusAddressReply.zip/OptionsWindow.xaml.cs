using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Interop;

namespace EasyPlusAddressReply
{
    public partial class OptionsWindow : Window
    {
        public bool UseDeliveryHeaderFallback => UseDeliveryHeadersToggle.IsChecked == true;
        public bool WarnOnAmbiguousMatch => WarnOnAmbiguousToggle.IsChecked == true;

        public OptionsWindow(bool useDeliveryHeaderFallback, bool warnOnAmbiguousMatch)
        {
            InitializeComponent();

            Title = Strings.Get("SettingsTitle");
            HeadingText.Text = Strings.Get("SettingsHeading");
            UseDeliveryHeadersTitleText.Text = Strings.Get("SettingsUseDeliveryHeaders");
            UseDeliveryHeadersDescriptionText.Text = Strings.Get("SettingsUseDeliveryHeadersDescription");
            WarnOnAmbiguousTitleText.Text = Strings.Get("SettingsWarnAmbiguous");
            WarnOnAmbiguousDescriptionText.Text = Strings.Get("SettingsWarnAmbiguousDescription");
            OkButton.Content = Strings.Get("OK");
            CancelButton.Content = Strings.Get("Cancel");

            UseDeliveryHeadersToggle.IsChecked = useDeliveryHeaderFallback;
            WarnOnAmbiguousToggle.IsChecked = warnOnAmbiguousMatch;
            UpdateStateLabels();
        }

        public bool? ShowDialogOwned()
        {
            try
            {
                IntPtr owner = NativeMethods.GetActiveWindow();
                if (owner != IntPtr.Zero)
                    new WindowInteropHelper(this).Owner = owner;
            }
            catch
            {
                // Falling back to a normal modal WPF window is safe if an HWND cannot be resolved.
            }

            return ShowDialog();
        }

        private void SettingToggle_StateChanged(object sender, RoutedEventArgs e)
        {
            UpdateStateLabels();
        }

        private void UpdateStateLabels()
        {
            if (UseDeliveryHeadersStateText != null)
            {
                UseDeliveryHeadersStateText.Text = UseDeliveryHeadersToggle.IsChecked == true
                    ? Strings.Get("StateOn")
                    : Strings.Get("StateOff");
            }

            if (WarnOnAmbiguousStateText != null)
            {
                WarnOnAmbiguousStateText.Text = WarnOnAmbiguousToggle.IsChecked == true
                    ? Strings.Get("StateOn")
                    : Strings.Get("StateOff");
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private static class NativeMethods
        {
            [DllImport("user32.dll")]
            internal static extern IntPtr GetActiveWindow();
        }
    }
}
